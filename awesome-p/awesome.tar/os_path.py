import os
print(os.path.abspath('c:/users/pc-asus/Downloads/awesome-python3-webapp'))